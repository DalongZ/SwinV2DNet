import os
import sys
from collections import OrderedDict
import random
import numpy as np
import pandas as pd
import torch
import torch.backends.cudnn as cudnn
import torch.nn as nn
import torch.optim as optim
import copy

import torch.utils.data as Data
from torch.optim import lr_scheduler
from tqdm import tqdm
# from metrics import iou_score

import dataset as dates
from torch.utils.tensorboard import SummaryWriter
import torch.nn.functional as F

model_name = "sufccdn"
# from swinv2_unet_plus2 import swinv2_base_patch4_window12_192_22k as create_model
# from swinv2_unet_plus2 import SwinTransformerSys
from sufccdn import swinv2_unet_plus2_concat
# 修改device的地方为3处：train文件262行，373行；model文件871行
# 修改model名字


torch.backends.cudnn.enabled = True
torch.backends.cudnn.benchmark = True


class dice_loss(nn.Module):
    def __init__(self):
        super(dice_loss, self).__init__()

    def forward(self, output, target):
        dice = dice_coef_pytorch(output, target)
        # ce = F.cross_entropy(output, target.long())
        bce = F.binary_cross_entropy(output, target)
        # return bce
        return 0.5*dice + bce


def dice_coef_pytorch(output, target):
    smooth = 1e-4
    b = output.shape[0]

    # 下边四行属于关键代码，不要乱改
    # net_1 = nn.Softmax(dim=1)
    # output = net_1(output)
    # output = torch.max(output, dim=1)[0]
    # target = target.unsqueeze(dim=1)
    output = output.view(b, -1)
    target = target.view(b, -1)
    intersection = (output * target).sum(1)
    union = output.sum(1) + target.sum(1)
    coff = (2. * intersection + smooth) / (union + smooth)
    return 1 - coff.mean(0)


def score(output, target, threshold=0.5):
    # print(output.shape)   # torch.Size([8, 1, 256, 256])
    # print(target.shape)   # torch.Size([8, 1, 256, 256])
    TP = ((output >= threshold) & (target >= threshold)).sum()
    TN = ((output < threshold) & (target < threshold)).sum()
    FP = ((output >= threshold) & (target < threshold)).sum()
    FN = ((output < threshold) & (target >= threshold)).sum()
    return [int(TP), int(TN), int(FP), int(FN)]


def train(train_loader, model, criterion, optimizer, device1):
    precision = 0.0
    recall = 0.0
    F1 = 0.0
    OA = 0.0
    num = 0
    total_loss = 0.0
    iou = 0.0

    TP = 0
    TN = 0
    FP = 0
    FN = 0

    model.train()
    pbar = tqdm(total=len(train_loader))
    # for input1, target in train_loader:
    for input1, input2, target in train_loader:
        # compute output
        # outputs = model(input1.cuda(3))
        outputs = model(input1.to(device1), input2.to(device1))
        target = target.to(device1)
        loss = 0
        # 限制输出的范围
        # target = torch.clamp(target, 0.001, 0.999)
        for output in outputs:
            output = torch.clamp(output, 0.0001, 0.9999)
            loss += criterion(output, target)
        # loss = criterion(outputs, target)
        loss = loss / len(outputs)
        output = outputs[-1]  # [8,1,256,256]
        # 单张图片单张图片的进行计算
        # iou = 0.0
        for i in range(target.shape[0]):
        #     iou += iou_score(output[i], target[i])  # output5计算IOU
            num += 1
        # num += target.shape[0]
        # outputs = torch.argmax(outputs, dim=1)
        # print(outputs.shape)
        # print(target.shape)
        res = score(output, target)
        TP += res[0]
        TN += res[1]
        FP += res[2]
        FN += res[3]

        if TP != 0:
            precision = TP * 1.0 / (TP + FP)
            recall = TP * 1.0 / (TP + FN)
            F1 = 2 * precision * recall / (precision + recall)
            OA = (TP + TN) * 1.0 / (TP + TN + FP + FN)

        # compute gradient and do optimizing step
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
        postfix = OrderedDict([
            ('loss', total_loss / num),
            ('iou', iou / num),
            ('P', precision),
            ('R', recall),
            ('F1', F1),
            ('OA', OA),
        ])
        pbar.set_postfix(postfix)
        pbar.update(1)
    pbar.close()

    return OrderedDict([('loss', total_loss / num),
                        ('iou', iou / num),
                        ('P', float(precision)),
                        ('R', float(recall)),
                        ('F1', float(F1)),
                        ('OA', float(OA))])


def validate(val_loader, model, criterion, device1):
    precision = 0.0
    recall = 0.0
    F1 = 0.0
    OA = 0.0
    num = 0
    iou = 0.0
    total_loss = 0.0

    TP = 0
    TN = 0
    FP = 0
    FN = 0

    model.eval()
    with torch.no_grad():   # 验证不需要训练，所以不需要求梯度
        pbar = tqdm(total=len(val_loader))
        # for input1, target in val_loader:
        for input1, input2, target in val_loader:
            # compute output，如果使用深监督，loss的值是四个output求和取平均
            # outputs = model(input1.cuda(3))
            outputs = model(input1.to(device1), input2.to(device1))
            target = target.to(device1)
            # loss = criterion(outputs, target)
            loss = 0
            for output in outputs:
                output = torch.clamp(output, 0.0001, 0.9999)
                loss += criterion(output, target)
            loss = loss / len(outputs)
            output = outputs[-1]
            # iou = iou_score(outputs[-1], target)
            # 单张图片单张图片的进行计算
            # iou = 0.0
            for i in range(target.shape[0]):
            #     iou += iou_score(output[i], target[i])  # output5计算IOU
                num += 1
            # num += target.shape[0]
            # outputs = torch.argmax(outputs, dim=1)
            res = score(output, target)
            TP += res[0]
            TN += res[1]
            FP += res[2]
            FN += res[3]

            if TP != 0:
                precision = TP * 1.0 / (TP + FP)
                recall = TP * 1.0 / (TP + FN)
                F1 = 2 * precision * recall / (precision + recall)
                OA = (TP + TN) * 1.0 / (TP + TN + FP + FN)

            total_loss += loss.item()
            postfix = OrderedDict([
                ('loss', total_loss / num),
                ('iou', iou / num),
                ('P', float(precision)),
                ('R', float(recall)),
                ('F1', float(F1)),
                ('OA', float(OA))
            ])
            pbar.set_postfix(postfix)
            pbar.update(1)
        pbar.close()

        return OrderedDict([('loss', total_loss / num),
                            ('iou', iou / num),
                            ('P', float(precision)),
                            ('R', float(recall)),
                            ('F1', float(F1)),
                            ('OA', float(OA))])


# swinv2_unet++中完整的swin_unet预训练权重添加
"""def load_from(model1, path, cuda_device):
    pretrained_path = path
    if pretrained_path is not None:
        print("pretrained_path:{}".format(pretrained_path))
        device = cuda_device
        # device = torch.device('cuda:'+cuda_device if torch.cuda.is_available() else 'cpu')
        pretrained_dict = torch.load(pretrained_path, map_location=device)
        if "model" not in pretrained_dict:
            print("---start load pretrained model by splitting---")
            pretrained_dict = {k[17:]: v for k, v in pretrained_dict.items()}
            for k in list(pretrained_dict.keys()):
                if "output" in k:
                    print("delete key:{}".format(k))
                    del pretrained_dict[k]
            msg = model1.load_state_dict(pretrained_dict, strict=False)
            print(msg)
            return
        pretrained_dict = pretrained_dict['model']
        print("---start load pretrained model of swin encoder---")

        model_dict = model1.state_dict()
        full_dict = copy.deepcopy(pretrained_dict)
        for k, v in pretrained_dict.items():   # 创建后半段的预训练权重
            if "layers." in k:
                current_layer_num = 3-int(k[7:8])
                current_k = "layers_up." + str(current_layer_num) + k[8:]
                full_dict.update({current_k: v})
        for k in list(full_dict.keys()):
            if k in model_dict:
                if full_dict[k].shape != model_dict[k].shape:
                    print("delete:{};shape pretrain:{};shape model:{}".format(k, v.shape, model_dict[k].shape))
                    del full_dict[k]

        msg = model1.load_state_dict(full_dict, strict=False)
        print(msg)
    else:
        print("none pretrain")"""



def main():
    epochs = 150
    learning_rate = 0.00005   # 通常建议：batchsize为8则学习率设为1e-4，这两项同时两倍增减
    batch_size = 4
    device = torch.device("cuda:1" if torch.cuda.is_available() else "cpu")
    criterion = dice_loss()
    model = swinv2_unet_plus2_concat().to(device)
    # model = IFN_NestedUnet().to(device)
    # if torch.cuda.is_available():
    #     model = torch.nn.DataParallel(model)  # 多个GPU训练
    #     cudnn.benchmark = True   # 对于网络结构固定的。会在程序开始时花费额外的时间，为卷积层搜索最适合的卷积实现算法，从而实现加速
    #     model = model.cuda()

    # load_from(model1=model, path="/data/ym/weights/swinv2_base_patch4_window16_256.pth", cuda_device=device)
    """checkpoint = torch.load("/data/ym/weights/swinv2_base_patch4_window16_256.pth", map_location='cpu')
    weights_dict = checkpoint['model']
    for k in list(weights_dict.keys()):
        if "head" in k:
            del weights_dict[k]
    msg = model.load_state_dict(weights_dict, strict=False)
    print(msg)"""

    optimizer = optim.Adam(model.parameters(), lr=learning_rate)
    scheduler = lr_scheduler.StepLR(optimizer, step_size=5, gamma=0.90)

    base_path = os.path.join(r'/data/dalongzheng/CDD')
    train_txt_path = os.path.join(r'/data/dalongzheng/CDD', 'aug_train.txt')
    val_txt_path = os.path.join(r'/data/dalongzheng/CDD', 'test.txt')
    # val_txt_path = os.path.join('ACD2', 'test.txt')

    train_data = dates.Dataset1(base_path, train_txt_path, LEVIR=False)
    train_loader = Data.DataLoader(train_data, batch_size=batch_size, shuffle=True, num_workers=1, pin_memory=True)
    val_data = dates.Dataset1(base_path, val_txt_path, LEVIR=False)
    val_loader = Data.DataLoader(val_data, batch_size=batch_size, shuffle=False, num_workers=1, pin_memory=True)
    device1 = device

    log = OrderedDict([
        ('epoch', []),
        ('lr', []),
        ('loss', []),
        ('iou', []),
        ('precision', []),
        ('recall', []),
        ('F1', []),
        ('OA', []),
        ('val_loss', []),
        ('val_iou', []),
        ('val_precision', []),
        ('val_recall', []),
        ('val_F1', []),
        ('val_OA', []),
    ])
    best_f1 = 0.0

    for epoch in range(epochs):
        print('Epoch [%d/%d]' % (epoch + 1, epochs))
        # train for one epoch
        train_log = train(train_loader, model, criterion, optimizer, device1)
        # evaluate on validation set
        val_log = validate(val_loader, model, criterion, device1)
        # 学习率调整
        scheduler.step()
        # print("learning rate is ", optimizer.param_groups[0]["lr"])

        print(
            'train:loss %.4f - iou %.4f - precision %.4f - recall %.4f - F1 %.4f - OA %.4f\n val: loss %.4f - iou %.4f- precision %.4f - recall %.4f - F1 %.4f - OA %.4f '
            % (train_log['loss'], train_log['iou'], train_log['P'], train_log['R'], train_log['F1'],
               train_log['OA'],
               val_log['loss'], val_log['iou'], val_log['P'], val_log['R'], val_log['F1'], val_log['OA']))

        # tensorboard可视化
        # 使用命令：tensorboard - -logdir. / models / NestedUnetL4_CBAM / tensorboard
        log_dir = "LEVIR/" + model_name + "/tensorboard"
        writer = SummaryWriter(log_dir=log_dir)
        writer.add_scalars("loss", {"train_loss": train_log['loss'],
                                    "val_loss": val_log['loss']
                                    }, epoch + 1)
        writer.add_scalars("iou", {"train_iou": train_log['iou'],
                                   "val_iou": val_log['iou']}, epoch + 1)
        writer.add_scalars("Precision", {"train_P": train_log['P'],
                                         "val_P": val_log['P']}, epoch + 1)
        writer.add_scalars("Recall", {"train_R": train_log['R'],
                                      "val_R": val_log['R']}, epoch + 1)
        writer.add_scalars("F1", {"train_F1": train_log['F1'],
                                  "val_F1": val_log['F1']}, epoch + 1)
        writer.add_scalars("OA", {"train_OA": train_log['OA'],
                                  "val_OA": val_log['OA']}, epoch + 1)

        # 保存日志信息
        log['epoch'].append(epoch)
        log['lr'].append(optimizer.param_groups[0]["lr"])
        log['loss'].append(train_log['loss'])
        log['iou'].append(train_log['iou'])
        log['precision'].append(train_log['P'])
        log['recall'].append(train_log['R'])
        log['F1'].append(train_log['F1'])
        log['OA'].append(train_log['OA'])
        log['val_loss'].append(val_log['loss'])
        log['val_iou'].append(val_log['iou'])
        log['val_precision'].append(val_log['P'])
        log['val_recall'].append(val_log['R'])
        log['val_F1'].append(val_log['F1'])
        log['val_OA'].append(val_log['OA'])

        pd.DataFrame(log).to_csv('LEVIR/%s/log.csv' % model_name, index=False)

        if val_log['F1'] > best_f1:
            torch.save(model.state_dict(), 'LEVIR/%s/model.pth' % model_name)
            best_f1 = val_log['F1']
            print("=> saved best model")

        # 清除没有用的临时变量
        # torch.cuda.empty_cache()
        with torch.cuda.device('cuda:1'):
            torch.cuda.empty_cache()


# 在使用pytorch时，如果希望通过设置随机数种子，在GPU或CPU上固定每一次的训练结果，则需要在执行程序的开始添加下面代码：
# seed_torch(seed=666)   # 随机数种子确定时，模型的训练结果将保持一致
def seed_torch(seed):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    # torch.cuda.manual_seed_all(seed) # if you are using multi-GPU.
    torch.backends.cudnn.deterministic = True


if __name__ == '__main__':
    seed_torch(666)
    main()
    # file = open('/data/dalongzheng/swin_v2/swin_unet++_cd/models/swinv2_unet_plus2/1.txt', 'r')
    # print(file.readlines())  # 输出读取apple.txt里面的内容
    # file.close()


