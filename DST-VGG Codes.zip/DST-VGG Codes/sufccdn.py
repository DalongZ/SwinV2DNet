import torch
import torch.nn as nn
from torchvision.models import vgg16
import numpy as np
import copy
# from thop import profile


import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.utils.checkpoint as checkpoint
from timm.models.layers import DropPath, to_2tuple, trunc_normal_
import numpy as np
from einops import rearrange
from SFPT_f import FPT
from FCCDN1 import FCCDN


class Mlp(nn.Module):
    def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        self.fc1 = nn.Linear(in_features, hidden_features)
        self.act = act_layer()
        self.fc2 = nn.Linear(hidden_features, out_features)
        self.drop = nn.Dropout(drop)

    def forward(self, x):
        x = self.fc1(x)
        x = self.act(x)
        x = self.drop(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x


def window_partition(x, window_size):
    """
    Args:
        x: (B, H, W, C)
        window_size (int): window size

    Returns:
        windows: (num_windows*B, window_size, window_size, C)
    """
    B, H, W, C = x.shape
    x = x.view(B, H // window_size, window_size, W // window_size, window_size, C)
    windows = x.permute(0, 1, 3, 2, 4, 5).contiguous().view(-1, window_size, window_size, C)
    return windows


def window_reverse(windows, window_size, H, W):
    """
    Args:
        windows: (num_windows*B, window_size, window_size, C)
        window_size (int): Window size
        H (int): Height of image
        W (int): Width of image

    Returns:
        x: (B, H, W, C)
    """
    B = int(windows.shape[0] / (H * W / window_size / window_size))
    x = windows.view(B, H // window_size, W // window_size, window_size, window_size, -1)
    x = x.permute(0, 1, 3, 2, 4, 5).contiguous().view(B, H, W, -1)
    return x


class WindowAttention(nn.Module):
    r""" Window based multi-head self attention (W-MSA) module with relative position bias.
    It supports both of shifted and non-shifted window.

    Args:
        dim (int): Number of input channels.
        window_size (tuple[int]): The height and width of the window.
        num_heads (int): Number of attention heads.
        qkv_bias (bool, optional):  If True, add a learnable bias to query, key, value. Default: True
        attn_drop (float, optional): Dropout ratio of attention weight. Default: 0.0
        proj_drop (float, optional): Dropout ratio of output. Default: 0.0
        pretrained_window_size (tuple[int]): The height and width of the window in pre-training   比v1版本多的参数
        qk_scale (float | None, optional): Override default qk scale of head_dim ** -0.5 if set   比v1版本少的参数
    """

    def __init__(self, dim, window_size, num_heads, qkv_bias=True, attn_drop=0., proj_drop=0.,
                 pretrained_window_size=[0, 0]):

        super().__init__()
        self.dim = dim
        self.window_size = window_size  # Wh, Ww
        self.pretrained_window_size = pretrained_window_size
        self.num_heads = num_heads

        self.logit_scale = nn.Parameter(torch.log(10 * torch.ones((num_heads, 1, 1))), requires_grad=True)

        # mlp to generate continuous relative position bias
        self.cpb_mlp = nn.Sequential(nn.Linear(2, 512, bias=True),
                                     nn.ReLU(inplace=True),
                                     nn.Linear(512, num_heads, bias=False))

        # get relative_coords_table
        relative_coords_h = torch.arange(-(self.window_size[0] - 1), self.window_size[0], dtype=torch.float32)
        relative_coords_w = torch.arange(-(self.window_size[1] - 1), self.window_size[1], dtype=torch.float32)
        relative_coords_table = torch.stack(
            torch.meshgrid([relative_coords_h,
                            relative_coords_w])).permute(1, 2, 0).contiguous().unsqueeze(0)  # 1, 2*Wh-1, 2*Ww-1, 2
        if pretrained_window_size[0] > 0:
            relative_coords_table[:, :, :, 0] /= (pretrained_window_size[0] - 1)
            relative_coords_table[:, :, :, 1] /= (pretrained_window_size[1] - 1)
            # 位置偏置的实质是预训练的窗口大小和迁移后的窗口大小的比值
        else:
            relative_coords_table[:, :, :, 0] /= (self.window_size[0] - 1)
            relative_coords_table[:, :, :, 1] /= (self.window_size[1] - 1)
        relative_coords_table *= 8  # normalize to -8, 8
        relative_coords_table = torch.sign(relative_coords_table) * torch.log2(
            torch.abs(relative_coords_table) + 1.0) / np.log2(8)
        # 求出论文中的x和y的位置偏置，位置偏置的实质是预训练的窗口大小和迁移后的窗口大小的比值，是不可训练的输入

        self.register_buffer("relative_coords_table", relative_coords_table)

        # get pair-wise relative position index for each token inside the window
        coords_h = torch.arange(self.window_size[0])
        coords_w = torch.arange(self.window_size[1])
        coords = torch.stack(torch.meshgrid([coords_h, coords_w]))  # 2, Wh, Ww
        coords_flatten = torch.flatten(coords, 1)  # 2, Wh*Ww
        relative_coords = coords_flatten[:, :, None] - coords_flatten[:, None, :]  # 2, Wh*Ww, Wh*Ww
        relative_coords = relative_coords.permute(1, 2, 0).contiguous()  # Wh*Ww, Wh*Ww, 2
        relative_coords[:, :, 0] += self.window_size[0] - 1  # shift to start from 0
        relative_coords[:, :, 1] += self.window_size[1] - 1
        relative_coords[:, :, 0] *= 2 * self.window_size[1] - 1
        relative_position_index = relative_coords.sum(-1)  # Wh*Ww, Wh*Ww
        self.register_buffer("relative_position_index", relative_position_index)

        self.qkv = nn.Linear(dim, dim * 3, bias=False)
        if qkv_bias:
            self.q_bias = nn.Parameter(torch.zeros(dim))
            self.v_bias = nn.Parameter(torch.zeros(dim))
        else:
            self.q_bias = None
            self.v_bias = None
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)
        self.softmax = nn.Softmax(dim=-1)


    def forward(self, x, mask=None):
        """
        Args:
            x: input features with shape of (num_windows*B, N, C)
            mask: (0/-inf) mask with shape of (num_windows, Wh*Ww, Wh*Ww) or None
        """
        B_, N, C = x.shape
        qkv_bias = None
        if self.q_bias is not None:
            qkv_bias = torch.cat((self.q_bias, torch.zeros_like(self.v_bias, requires_grad=False), self.v_bias))
        qkv = F.linear(input=x, weight=self.qkv.weight, bias=qkv_bias)
        # swinv2版本增加了self.qkv.weight和qkv_bias
        qkv = qkv.reshape(B_, N, 3, self.num_heads, -1).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]  # make torchscript happy (cannot use tensor as tuple)

        # swinv2原文改进处2（scaled cosine attention）：其代码实现似乎与数学名称不符，对q，k和logit_scale都做了相应的归一化
        attn = (F.normalize(q, dim=-1) @ F.normalize(k, dim=-1).transpose(-2, -1))
        logit_scale = torch.clamp(self.logit_scale, max=torch.log(torch.tensor(1. / 0.01))).exp()
        attn = attn * logit_scale

        # swinv2原文改进处3（log-spaced continuous相对位置偏置方法）
        relative_position_bias_table = self.cpb_mlp(self.relative_coords_table).view(-1, self.num_heads)
        relative_position_bias = relative_position_bias_table[self.relative_position_index.view(-1)].view(
            self.window_size[0] * self.window_size[1], self.window_size[0] * self.window_size[1], -1)  # Wh*Ww,Wh*Ww,nH
        relative_position_bias = relative_position_bias.permute(2, 0, 1).contiguous()  # nH, Wh*Ww, Wh*Ww
        relative_position_bias = 16 * torch.sigmoid(relative_position_bias)
        attn = attn + relative_position_bias.unsqueeze(0)

        if mask is not None:
            nW = mask.shape[0]
            attn = attn.view(B_ // nW, nW, self.num_heads, N, N) + mask.unsqueeze(1).unsqueeze(0)
            attn = attn.view(-1, self.num_heads, N, N)
            attn = self.softmax(attn)
        else:
            attn = self.softmax(attn)

        attn = self.attn_drop(attn)

        x = (attn @ v).transpose(1, 2).reshape(B_, N, C)
        x = self.proj(x)
        x = self.proj_drop(x)
        return x


    def extra_repr(self) -> str:
        return f'dim={self.dim}, window_size={self.window_size}, ' \
               f'pretrained_window_size={self.pretrained_window_size}, num_heads={self.num_heads}'

    def flops(self, N):
        # calculate flops for 1 window with token length of N
        flops = 0
        # qkv = self.qkv(x)
        flops += N * self.dim * 3 * self.dim
        # attn = (q @ k.transpose(-2, -1))
        flops += self.num_heads * N * (self.dim // self.num_heads) * N
        #  x = (attn @ v)
        flops += self.num_heads * N * N * (self.dim // self.num_heads)
        # x = self.proj(x)
        flops += N * self.dim * self.dim
        return flops


class SwinTransformerBlock(nn.Module):
    r""" Swin Transformer Block.

    Args:
        dim (int): Number of input channels.
        input_resolution (tuple[int]): Input resulotion.
        num_heads (int): Number of attention heads.
        window_size (int): Window size.
        shift_size (int): Shift size for SW-MSA.
        mlp_ratio (float): Ratio of mlp hidden dim to embedding dim.
        qkv_bias (bool, optional): If True, add a learnable bias to query, key, value. Default: True
        drop (float, optional): Dropout rate. Default: 0.0
        attn_drop (float, optional): Attention dropout rate. Default: 0.0
        drop_path (float, optional): Stochastic depth rate. Default: 0.0
        act_layer (nn.Module, optional): Activation layer. Default: nn.GELU
        norm_layer (nn.Module, optional): Normalization layer.  Default: nn.LayerNorm
        pretrained_window_size (int): Window size in pre-training.
    """

    def __init__(self, dim, input_resolution, num_heads, window_size=7, shift_size=0,
                 mlp_ratio=4., qkv_bias=True, drop=0., attn_drop=0., drop_path=0.,
                 act_layer=nn.GELU, norm_layer=nn.LayerNorm, pretrained_window_size=0):
        super().__init__()

        self.dim = dim
        self.input_resolution = input_resolution
        self.num_heads = num_heads
        self.window_size = window_size
        self.shift_size = shift_size
        self.mlp_ratio = mlp_ratio

        if min(self.input_resolution) <= self.window_size:
            # if window size is larger than input resolution, we don't partition windows
            self.shift_size = 0
            self.window_size = min(self.input_resolution)
        assert 0 <= self.shift_size < self.window_size, "shift_size must in 0-window_size"

        self.norm1 = norm_layer(dim)
        self.attn = WindowAttention(
            dim, window_size=to_2tuple(self.window_size), num_heads=num_heads,
            qkv_bias=qkv_bias, attn_drop=attn_drop, proj_drop=drop,
            pretrained_window_size=to_2tuple(pretrained_window_size))

        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.norm2 = norm_layer(dim)
        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = Mlp(in_features=dim, hidden_features=mlp_hidden_dim, act_layer=act_layer, drop=drop)

        if self.shift_size > 0:
            # calculate attention mask for SW-MSA
            H, W = self.input_resolution
            img_mask = torch.zeros((1, H, W, 1))  # 1 H W 1
            h_slices = (slice(0, -self.window_size),
                        slice(-self.window_size, -self.shift_size),
                        slice(-self.shift_size, None))
            w_slices = (slice(0, -self.window_size),
                        slice(-self.window_size, -self.shift_size),
                        slice(-self.shift_size, None))
            cnt = 0
            for h in h_slices:
                for w in w_slices:
                    img_mask[:, h, w, :] = cnt
                    cnt += 1

            mask_windows = window_partition(img_mask, self.window_size)  # nW, window_size, window_size, 1
            mask_windows = mask_windows.view(-1, self.window_size * self.window_size)
            attn_mask = mask_windows.unsqueeze(1) - mask_windows.unsqueeze(2)
            attn_mask = attn_mask.masked_fill(attn_mask != 0, float(-100.0)).masked_fill(attn_mask == 0, float(0.0))
        else:
            attn_mask = None

        self.register_buffer("attn_mask", attn_mask)


    def forward(self, x):
        H, W = self.input_resolution
        B, L, C = x.shape
        assert L == H * W, "input feature has wrong size"

        shortcut = x
        x = x.view(B, H, W, C)

        # cyclic shift
        if self.shift_size > 0:
            shifted_x = torch.roll(x, shifts=(-self.shift_size, -self.shift_size), dims=(1, 2))
        else:
            shifted_x = x

        # partition windows
        x_windows = window_partition(shifted_x, self.window_size)  # nW*B, window_size, window_size, C
        x_windows = x_windows.view(-1, self.window_size * self.window_size, C)  # nW*B, window_size*window_size, C

        # W-MSA/SW-MSA
        attn_windows = self.attn(x_windows, mask=self.attn_mask)  # nW*B, window_size*window_size, C

        # merge windows
        attn_windows = attn_windows.view(-1, self.window_size, self.window_size, C)
        shifted_x = window_reverse(attn_windows, self.window_size, H, W)  # B H' W' C

        # reverse cyclic shift
        if self.shift_size > 0:
            x = torch.roll(shifted_x, shifts=(self.shift_size, self.shift_size), dims=(1, 2))
        else:
            x = shifted_x
        x = x.view(B, H * W, C)
        # swinv2原文改进处1（post-norm）
        x = shortcut + self.drop_path(self.norm1(x))

        # FFN
        # swinv2原文改进处1（post-norm）
        x = x + self.drop_path(self.norm2(self.mlp(x)))

        return x


    def extra_repr(self) -> str:
        return f"dim={self.dim}, input_resolution={self.input_resolution}, num_heads={self.num_heads}, " \
               f"window_size={self.window_size}, shift_size={self.shift_size}, mlp_ratio={self.mlp_ratio}"

    def flops(self):
        flops = 0
        H, W = self.input_resolution
        # norm1
        flops += self.dim * H * W
        # W-MSA/SW-MSA
        nW = H * W / self.window_size / self.window_size
        flops += nW * self.attn.flops(self.window_size * self.window_size)
        # mlp
        flops += 2 * H * W * self.dim * self.dim * self.mlp_ratio
        # norm2
        flops += self.dim * H * W
        return flops


class PatchMerging(nn.Module):
    r""" Patch Merging Layer.

    Args:
        input_resolution (tuple[int]): Resolution of input feature.
        dim (int): Number of input channels.
        norm_layer (nn.Module, optional): Normalization layer.  Default: nn.LayerNorm
    """

    def __init__(self, input_resolution, dim, norm_layer=nn.LayerNorm):
        super().__init__()
        self.input_resolution = input_resolution
        self.dim = dim
        self.reduction = nn.Linear(4 * dim, 2 * dim, bias=False)
        self.norm = norm_layer(2 * dim)

    def forward(self, x):
        """
        x: B, H*W, C
        """
        H, W = self.input_resolution
        B, L, C = x.shape
        assert L == H * W, "input feature has wrong size"
        assert H % 2 == 0 and W % 2 == 0, f"x size ({H}*{W}) are not even."

        x = x.view(B, H, W, C)

        x0 = x[:, 0::2, 0::2, :]  # B H/2 W/2 C
        x1 = x[:, 1::2, 0::2, :]  # B H/2 W/2 C
        x2 = x[:, 0::2, 1::2, :]  # B H/2 W/2 C
        x3 = x[:, 1::2, 1::2, :]  # B H/2 W/2 C
        x = torch.cat([x0, x1, x2, x3], -1)  # B H/2 W/2 4*C
        x = x.view(B, -1, 4 * C)  # B H/2*W/2 4*C

        # swinv2此处把这两个模块的顺序做了颠倒
        x = self.reduction(x)
        x = self.norm(x)

        return x


    def extra_repr(self) -> str:
        return f"input_resolution={self.input_resolution}, dim={self.dim}"

    def flops(self):
        H, W = self.input_resolution
        flops = (H // 2) * (W // 2) * 4 * self.dim * 2 * self.dim
        flops += H * W * self.dim // 2
        return flops


# swinv2_unet++
class PatchExpand(nn.Module):   # 例如：(1, 256, 8C) -> (1, 256, 16C) -> (1, 1024, 4C)
    # 改为：(1, 256, 8C) -> (1, 256, 8C) -> (1, 1024, 2C)
    def __init__(self, input_resolution, dim, dim_scale=2, norm_layer=nn.LayerNorm):
        super().__init__()
        self.input_resolution = input_resolution
        self.dim = dim
        self.expand = nn.Linear(dim, 2*dim, bias=False) if dim_scale==2 else nn.Identity()
        self.norm = norm_layer(dim // dim_scale)

    def forward(self, x):
        """
        x: B, H*W, C
        """
        H, W = self.input_resolution
        x = self.expand(x)
        B, L, C = x.shape
        assert L == H * W, "input feature has wrong size"

        x = x.view(B, H, W, C)
        x = rearrange(x, 'b h w (p1 p2 c)-> b (h p1) (w p2) c', p1=2, p2=2, c=C//4)
        x = x.view(B,-1,C//4)
        x= self.norm(x)

        return x


# swinv2_unet++
class FinalPatchExpand_X4(nn.Module):   # (1, 256, C) -> (1, 256, 16C) -> (1, 4096, C)
    def __init__(self, input_resolution, dim, dim_scale=4, norm_layer=nn.LayerNorm):
        super().__init__()
        self.input_resolution = input_resolution
        self.dim = dim
        self.dim_scale = dim_scale
        self.expand = nn.Linear(dim, 16*dim, bias=False)
        self.output_dim = dim
        self.norm = norm_layer(self.output_dim)

    def forward(self, x):
        """
        x: B, H*W, C
        """
        H, W = self.input_resolution
        x = self.expand(x)
        B, L, C = x.shape
        assert L == H * W, "input feature has wrong size"

        x = x.view(B, H, W, C)
        x = rearrange(x, 'b h w (p1 p2 c)-> b (h p1) (w p2) c', p1=self.dim_scale, p2=self.dim_scale, c=C//(self.dim_scale**2))
        x = x.view(B,-1,self.output_dim)
        x= self.norm(x)

        return x


# BasicLayer形状：swinv2*2，下采样；swinv2*2，下采样；swinv2*2，下采样；swinv2*2
class BasicLayer(nn.Module):
    """ A basic Swin Transformer layer for one stage.

    Args:
        dim (int): Number of input channels.
        input_resolution (tuple[int]): Input resolution.
        depth (int): Number of blocks.
        num_heads (int): Number of attention heads.
        window_size (int): Local window size.
        mlp_ratio (float): Ratio of mlp hidden dim to embedding dim.
        qkv_bias (bool, optional): If True, add a learnable bias to query, key, value. Default: True
        drop (float, optional): Dropout rate. Default: 0.0
        attn_drop (float, optional): Attention dropout rate. Default: 0.0
        drop_path (float | tuple[float], optional): Stochastic depth rate. Default: 0.0
        norm_layer (nn.Module, optional): Normalization layer. Default: nn.LayerNorm
        downsample (nn.Module | None, optional): Downsample layer at the end of the layer. Default: None
        use_checkpoint (bool): Whether to use checkpointing to save memory. Default: False.
        pretrained_window_size (int): Local window size in pre-training.
    """

    def __init__(self, dim, input_resolution, depth, num_heads, window_size,
                 mlp_ratio=4., qkv_bias=True, drop=0., attn_drop=0.,
                 drop_path=0., norm_layer=nn.LayerNorm, downsample=None, use_checkpoint=False,
                 pretrained_window_size=0):

        super().__init__()
        self.dim = dim
        self.input_resolution = input_resolution
        self.depth = depth
        self.use_checkpoint = use_checkpoint

        # build blocks
        self.blocks = nn.ModuleList([
            SwinTransformerBlock(dim=dim, input_resolution=input_resolution,
                                 num_heads=num_heads, window_size=window_size,
                                 shift_size=0 if (i % 2 == 0) else window_size // 2,
                                 mlp_ratio=mlp_ratio,
                                 qkv_bias=qkv_bias,
                                 drop=drop, attn_drop=attn_drop,
                                 drop_path=drop_path[i] if isinstance(drop_path, list) else drop_path,
                                 norm_layer=norm_layer,
                                 pretrained_window_size=pretrained_window_size)
            for i in range(depth)])

        # patch merging layer
        if downsample is not None:
            self.downsample = downsample(input_resolution, dim=dim, norm_layer=norm_layer)
        else:
            self.downsample = None

    def forward(self, x):
        for blk in self.blocks:
            if self.use_checkpoint:
                x = checkpoint.checkpoint(blk, x)
            else:
                x = blk(x)
        if self.downsample is not None:
            x = self.downsample(x)
        return x

    def extra_repr(self) -> str:
        return f"dim={self.dim}, input_resolution={self.input_resolution}, depth={self.depth}"

    def flops(self):
        flops = 0
        for blk in self.blocks:
            flops += blk.flops()
        if self.downsample is not None:
            flops += self.downsample.flops()
        return flops

    def _init_respostnorm(self):
        for blk in self.blocks:
            nn.init.constant_(blk.norm1.bias, 0)
            nn.init.constant_(blk.norm1.weight, 0)
            nn.init.constant_(blk.norm2.bias, 0)
            nn.init.constant_(blk.norm2.weight, 0)


# swinv2_unet++
# BasicLayer_up形状：上采样；swinv2*2，上采样；swinv2*2，上采样；swinv2*2
class BasicLayer_up(nn.Module):
    """ A basic Swin Transformer layer for one stage.

    Args:
        dim (int): Number of input channels.
        input_resolution (tuple[int]): Input resolution.
        depth (int): Number of blocks.
        num_heads (int): Number of attention heads.
        window_size (int): Local window size.
        mlp_ratio (float): Ratio of mlp hidden dim to embedding dim.
        qkv_bias (bool, optional): If True, add a learnable bias to query, key, value. Default: True
        qk_scale (float | None, optional): Override default qk scale of head_dim ** -0.5 if set.
        drop (float, optional): Dropout rate. Default: 0.0
        attn_drop (float, optional): Attention dropout rate. Default: 0.0
        drop_path (float | tuple[float], optional): Stochastic depth rate. Default: 0.0
        norm_layer (nn.Module, optional): Normalization layer. Default: nn.LayerNorm
        downsample (nn.Module | None, optional): Downsample layer at the end of the layer. Default: None
        use_checkpoint (bool): Whether to use checkpointing to save memory. Default: False.
    """

    def __init__(self, dim, input_resolution, depth, num_heads, window_size,
                 mlp_ratio=4., qkv_bias=True, drop=0., attn_drop=0.,
                 drop_path=0., norm_layer=nn.LayerNorm, upsample=None, use_checkpoint=False,
                 pretrained_window_size=0):

        super().__init__()
        self.dim = dim
        self.input_resolution = input_resolution
        self.depth = depth
        self.use_checkpoint = use_checkpoint

        # build blocks
        self.blocks = nn.ModuleList([
            SwinTransformerBlock(dim=dim, input_resolution=input_resolution,
                                 num_heads=num_heads, window_size=window_size,
                                 shift_size=0 if (i % 2 == 0) else window_size // 2,
                                 mlp_ratio=mlp_ratio,
                                 qkv_bias=qkv_bias,
                                 drop=drop, attn_drop=attn_drop,
                                 drop_path=drop_path[i] if isinstance(drop_path, list) else drop_path,
                                 norm_layer=norm_layer,
                                 pretrained_window_size=pretrained_window_size)
            for i in range(depth)])

        # patch merging layer
        if upsample is not None:
            self.upsample = PatchExpand(input_resolution, dim=dim, dim_scale=2, norm_layer=norm_layer)
        else:
            self.upsample = None

    def forward(self, x):
        for blk in self.blocks:
            if self.use_checkpoint:
                x = checkpoint.checkpoint(blk, x)
            else:
                x = blk(x)
        if self.upsample is not None:
            x = self.upsample(x)
        return x


class PatchEmbed(nn.Module):   # 己修改的参数于内部固定
    r""" Image to Patch Embedding

    Args:
        img_size (int): Image size.  Default: 224.
        patch_size (int): Patch token size. Default: 4.   # 下采样的倍率
        in_chans (int): Number of input image channels. Default: 3.
        embed_dim (int): Number of linear projection output channels. Default: 96.
        norm_layer (nn.Module, optional): Normalization layer. Default: None
    """

    def __init__(self, img_size=256, patch_size=4, in_chans=6, embed_dim=128, norm_layer=None):
        super().__init__()

        img_size = to_2tuple(img_size)
        patch_size = to_2tuple(patch_size)
        patches_resolution = [img_size[0] // patch_size[0], img_size[1] // patch_size[1]]
        self.img_size = img_size
        self.patch_size = patch_size
        self.patches_resolution = patches_resolution
        self.num_patches = patches_resolution[0] * patches_resolution[1]

        self.in_chans = in_chans
        self.embed_dim = embed_dim

        self.proj = nn.Conv2d(6, 128, kernel_size=4, stride=4)   # (6, 256, 256) -> (128, 64, 64)
        if norm_layer is not None:
            self.norm = norm_layer(128)
        else:
            self.norm = None

    def forward(self, x):
        B, C, H, W = x.shape
        # FIXME look at relaxing size constraints
        assert H == self.img_size[0] and W == self.img_size[1], \
            f"Input image size ({H}*{W}) doesn't match model ({self.img_size[0]}*{self.img_size[1]})."
        x = self.proj(x).flatten(2).transpose(1, 2)  # B Ph*Pw C   # (128, 64, 64) -> (64*64, 128)
        if self.norm is not None:
            x = self.norm(x)
        return x

    def flops(self):
        Ho, Wo = self.patches_resolution
        flops = Ho * Wo * self.embed_dim * self.in_chans * (self.patch_size[0] * self.patch_size[1])
        if self.norm is not None:
            flops += Ho * Wo * self.embed_dim
        return flops


# swinv2_unet++
class SwinTransformerSys(nn.Module):
    r""" Swin Transformer
        A PyTorch impl of : `Swin Transformer: Hierarchical Vision Transformer using Shifted Windows`  -
          https://arxiv.org/pdf/2103.14030

    Args:
        img_size (int | tuple(int)): Input image size. Default 224
        patch_size (int | tuple(int)): Patch size. Default: 4
        in_chans (int): Number of input image channels. Default: 3
        num_classes (int): Number of classes for classification head. Default: 1000
        embed_dim (int): Patch embedding dimension. Default: 96
        depths (tuple(int)): Depth of each Swin Transformer layer.
        num_heads (tuple(int)): Number of attention heads in different layers.
        window_size (int): Window size. Default: 7
        mlp_ratio (float): Ratio of mlp hidden dim to embedding dim. Default: 4
        qkv_bias (bool): If True, add a learnable bias to query, key, value. Default: True
        qk_scale (float): Override default qk scale of head_dim ** -0.5 if set. Default: None
        drop_rate (float): Dropout rate. Default: 0
        attn_drop_rate (float): Attention dropout rate. Default: 0
        drop_path_rate (float): Stochastic depth rate. Default: 0.1
        norm_layer (nn.Module): Normalization layer. Default: nn.LayerNorm.
        ape (bool): If True, add absolute position embedding to the patch embedding. Default: False
        patch_norm (bool): If True, add normalization after patch embedding. Default: True
        use_checkpoint (bool): Whether to use checkpointing to save memory. Default: False
    """

    def __init__(self, img_size=256, patch_size=4, in_chans=32, num_classes=2,
                 embed_dim=128, depths=[2, 2, 18, 2], depths_decoder=[1, 18, 2, 2], num_heads=[4, 8, 16, 32],
                 window_size=16, mlp_ratio=4., qkv_bias=True,
                 drop_rate=0., attn_drop_rate=0., drop_path_rate=0.5,
                 norm_layer=nn.LayerNorm, ape=False, patch_norm=True,
                 use_checkpoint=False, pretrained_window_sizes=[0, 0, 0, 0], final_upsample="expand_first", **kwargs):
        super().__init__()

        print(
            "SwinTransformerSys expand initial----depths:{};depths_decoder:{};drop_path_rate:{};num_classes:{}".format(
                depths,
                depths_decoder, drop_path_rate, num_classes))

        self.num_classes = num_classes
        self.num_layers = len(depths)
        self.embed_dim = embed_dim
        self.ape = ape
        self.patch_norm = patch_norm
        self.num_features = int(embed_dim * 2 ** (self.num_layers - 1))
        self.num_features_up = int(embed_dim * 2)   # SwinTransformerSys另有参数
        self.mlp_ratio = mlp_ratio
        self.final_upsample = final_upsample   # SwinTransformerSys另有参数
        # self.conv2_final = nn.Conv2d(2, 1, kernel_size=3, stride=1, padding=1, bias=False)

        # split image into non-overlapping patches
        self.patch_embed = PatchEmbed(
            img_size=img_size, patch_size=patch_size, in_chans=in_chans, embed_dim=embed_dim,
            norm_layer=norm_layer if self.patch_norm else None)
        num_patches = self.patch_embed.num_patches
        patches_resolution = self.patch_embed.patches_resolution
        self.patches_resolution = patches_resolution

        # absolute position embedding
        if self.ape:
            self.absolute_pos_embed = nn.Parameter(torch.zeros(1, num_patches, embed_dim))
            trunc_normal_(self.absolute_pos_embed, std=.02)

        self.pos_drop = nn.Dropout(p=drop_rate)

        # stochastic depth
        dpr = [x.item() for x in torch.linspace(0, drop_path_rate, sum(depths))]  # stochastic depth decay rule

        # build encoder and bottleneck layers
        self.layers = nn.ModuleList()
        for i_layer in range(self.num_layers):
            layer = BasicLayer(dim=int(embed_dim * 2 ** i_layer),
                               input_resolution=(patches_resolution[0] // (2 ** i_layer),
                                                 patches_resolution[1] // (2 ** i_layer)),
                               depth=depths[i_layer],
                               num_heads=num_heads[i_layer],
                               window_size=window_size,
                               mlp_ratio=self.mlp_ratio,
                               qkv_bias=qkv_bias,
                               drop=drop_rate, attn_drop=attn_drop_rate,
                               drop_path=dpr[sum(depths[:i_layer]):sum(depths[:i_layer + 1])],
                               norm_layer=norm_layer,
                               downsample=PatchMerging if (i_layer < self.num_layers - 1) else None,
                               use_checkpoint=use_checkpoint,
                               pretrained_window_size=pretrained_window_sizes[i_layer])
            self.layers.append(layer)

        # build decoder layers   SwinTransformerSys另有参数
        self.layers_up = nn.ModuleList()
        self.concat_back_dim = nn.ModuleList()
        for i_layer in range(self.num_layers):
            concat_linear = nn.Linear(2 * int(embed_dim * 2 ** (self.num_layers - 1 - i_layer)),
                                      int(embed_dim * 2 ** (
                                                  self.num_layers - 1 - i_layer))) if i_layer > 0 else nn.Identity()
            if i_layer == 0:
                layer_up = PatchExpand(
                    input_resolution=(patches_resolution[0] // (2 ** (self.num_layers - 1 - i_layer)),
                                      patches_resolution[1] // (2 ** (self.num_layers - 1 - i_layer))),
                    dim=int(embed_dim * 2 ** (self.num_layers - 1 - i_layer)), dim_scale=2, norm_layer=norm_layer)
            else:
                layer_up = BasicLayer_up(dim=int(embed_dim * 2 ** (self.num_layers - 1 - i_layer)),
                                         input_resolution=(
                                         patches_resolution[0] // (2 ** (self.num_layers - 1 - i_layer)),
                                         patches_resolution[1] // (2 ** (self.num_layers - 1 - i_layer))),
                                         depth=depths[(self.num_layers - 1 - i_layer)],
                                         num_heads=num_heads[(self.num_layers - 1 - i_layer)],
                                         window_size=window_size,
                                         mlp_ratio=self.mlp_ratio,
                                         qkv_bias=qkv_bias,
                                         drop=drop_rate, attn_drop=attn_drop_rate,
                                         drop_path=dpr[sum(depths[:(self.num_layers - 1 - i_layer)]):sum(
                                             depths[:(self.num_layers - 1 - i_layer) + 1])],
                                         norm_layer=norm_layer,
                                         upsample=PatchExpand if (i_layer < self.num_layers - 1) else None,
                                         use_checkpoint=use_checkpoint,
                                         pretrained_window_size=pretrained_window_sizes[i_layer])
            self.layers_up.append(layer_up)
            self.concat_back_dim.append(concat_linear)

        self.norm = norm_layer(self.num_features)
        self.norm_up = norm_layer(self.embed_dim)   # SwinTransformerSys另有参数
        self.avgpool = nn.AdaptiveAvgPool1d(1)   # swinv2另有参数
        self.head = nn.Linear(self.num_features, num_classes) if num_classes > 0 else nn.Identity()   # swinv2另有参数

        if self.final_upsample == "expand_first":   # SwinTransformerSys另有参数
            print("---final upsample expand_first---")
            self.up = FinalPatchExpand_X4(input_resolution=(img_size // patch_size, img_size // patch_size),
                                          dim_scale=4, dim=embed_dim)
            self.output = nn.Conv2d(in_channels=embed_dim, out_channels=self.num_classes, kernel_size=1, bias=False)

        self.apply(self._init_weights)
        for bly in self.layers:
            bly._init_respostnorm()   # swinv2增加了该模块的零初始化

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)

    @torch.jit.ignore
    def no_weight_decay(self):
        return {'absolute_pos_embed'}

    @torch.jit.ignore
    def no_weight_decay_keywords(self):
        return {"cpb_mlp", "logit_scale", 'relative_position_bias_table'}

    # Encoder and Bottleneck
    def forward_features(self, x):
        x = self.patch_embed(x)
        if self.ape:
            x = x + self.absolute_pos_embed
        x = self.pos_drop(x)
        x_downsample = []

        for layer in self.layers:
            x_downsample.append(x)
            x = layer(x)

        x = self.norm(x)  # B L C

        return x, x_downsample

    # Dencoder and Skip connection
    def forward_up_features(self, x, x_downsample):
        x_up = []   # 己模型需处理的取值
        for inx, layer_up in enumerate(self.layers_up):
            if inx == 0:
                x = layer_up(x)
            else:
                x = torch.cat([x, x_downsample[3 - inx]], -1)
                x = self.concat_back_dim[inx](x)
                x = layer_up(x)
            x_up.append(x)

        x = self.norm_up(x)  # B L C

        return x, x_up

    def up_x4(self, x):
        H, W = self.patches_resolution
        B, L, C = x.shape
        assert L == H * W, "input features has wrong size"

        if self.final_upsample == "expand_first":
            x = self.up(x)
            x = x.view(B, 4 * H, 4 * W, -1)
            x = x.permute(0, 3, 1, 2)  # B,C,H,W
            x = self.output(x)

        return x

    def forward(self, x):   # SwinTransformerSys的传播函数

        x, x_downsample = self.forward_features(x)
        x = self.forward_up_features(x, x_downsample)
        x = self.up_x4(x)
        # x = self.conv2_final(x)

        return x

    def flops(self):
        flops = 0
        flops += self.patch_embed.flops()
        for i, layer in enumerate(self.layers):
            flops += layer.flops()
        flops += self.num_features * self.patches_resolution[0] * self.patches_resolution[1] // (2 ** self.num_layers)
        flops += self.num_features * self.num_classes
        return flops


def swinv2_base_patch4_window12_192_22k(num_classes: int = 2, **kwargs):   # 实际用的ImageNet-1K的256*256的权重
    model = SwinTransformerSys(in_chans=32,
                            patch_size=4,
                            window_size=16,
                            embed_dim=128,
                            depths=(2, 2, 18, 2),
                            num_heads=(4, 8, 16, 32),
                            num_classes=num_classes,
                            **kwargs)
    return model


def load_from(model1, path):
    pretrained_path = path
    if pretrained_path is not None:
        print("pretrained_path:{}".format(pretrained_path))
        device = torch.device("cuda:1" if torch.cuda.is_available() else "cpu")
        # device = torch.device('cuda:'+cuda_device if torch.cuda.is_available() else 'cpu')
        pretrained_dict = torch.load(pretrained_path, map_location=device)
        if "model" not in pretrained_dict:
            print("---start load pretrained model by splitting---")
            pretrained_dict = {k[17:]: v for k, v in pretrained_dict.items()}
            for k in list(pretrained_dict.keys()):
                if "output" in k:
                    print("delete key:{}".format(k))
                    del pretrained_dict[k]
            msg = model1.load_state_dict(pretrained_dict, strict=False)
            print(msg)
            return
        pretrained_dict = pretrained_dict['model']
        print("---start load pretrained model of swin encoder---")

        model_dict = model1.state_dict()
        full_dict = copy.deepcopy(pretrained_dict)
        for k, v in pretrained_dict.items():   # 创建后半段的预训练权重
            if "layers." in k:
                current_layer_num = 3-int(k[7:8])
                current_k = "layers_up." + str(current_layer_num) + k[8:]
                full_dict.update({current_k: v})
        for k in list(full_dict.keys()):
            if k in model_dict:
                if full_dict[k].shape != model_dict[k].shape:
                    print("delete:{};shape pretrain:{};shape model:{}".format(k, v.shape, model_dict[k].shape))
                    del full_dict[k]

        msg = model1.load_state_dict(full_dict, strict=False)
        print(msg)
    else:
        print("none pretrain")










"""
class vgg16_base(nn.Module):
    def __init__(self):
        super(vgg16_base, self).__init__()
        with torch.no_grad():
            features = list(vgg16(pretrained=True).features)[:-1]
            self.features = nn.ModuleList(features)
            # dict_1 = self.features.state_dict()
            # print("model_dict_1['layers.0.blocks.0.norm1.weight']: ", dict_1['layers.0.blocks.0.norm1.weight'])
            # self.features.requires_grad_(False)

    def forward(self, x):
        results = []
        for ii, model in enumerate(self.features):
            x = model(x)
            # print(x.shape)
            if ii in {3, 8, 15, 22, 29}:
                results.append(x)
        return results
"""


class ChannelAttention(nn.Module):
    def __init__(self, in_channels, ratio=16):  # INF原文中是8，为了减少参数量，我改成了16
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        self.fc1 = nn.Conv2d(in_channels, in_channels // ratio, 1, bias=False)
        self.relu1 = nn.ReLU(inplace=True)
        self.fc2 = nn.Conv2d(in_channels // ratio, in_channels, 1, bias=False)
        self.sigmod = nn.Sigmoid()

    def forward(self, x):
        avg_out = self.fc2(self.relu1(self.fc1(self.avg_pool(x))))
        max_out = self.fc2(self.relu1(self.fc1(self.max_pool(x))))
        out = avg_out + max_out
        return self.sigmod(out)


class SpatialAttention(nn.Module):
    def __init__(self):
        super(SpatialAttention, self).__init__()
        self.conv1 = nn.Conv2d(2, 1, 7, padding=3, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out = torch.max(x, dim=1, keepdim=True, out=None)[0]

        x = torch.cat([avg_out, max_out], dim=1)
        x = self.conv1(x)
        return self.sigmoid(x)


class VggBlock(nn.Module):
    def __init__(self, in_channels, middle_channels, out_channels):
        super().__init__()
        self.conv1 = conv2d_bn(in_channels, middle_channels)
        self.conv2 = conv2d_bn(middle_channels, out_channels)

    def forward(self, x):
        x = self.conv1(x)
        x = self.conv2(x)
        return x


def conv2d_bn(in_channels, out_channels):
    return nn.Sequential(
        nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=1, padding=1),
        nn.BatchNorm2d(out_channels),
        nn.ReLU(inplace=True),
    )


class up(nn.Module):
    def __init__(self, in_ch, bilinear=False):
        super(up, self).__init__()
        if bilinear:
            self.up = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        else:
            self.up = nn.ConvTranspose2d(in_ch, in_ch, 2, stride=2)

    def forward(self, x):
        x = self.up(x)
        return x


class up_1(nn.Module):
    def __init__(self, in_ch, bilinear=False):
        super(up_1, self).__init__()
        if bilinear:
            self.up = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        else:
            self.up = nn.ConvTranspose2d(in_ch, in_ch, 4, stride=4)

    def forward(self, x):
        x = self.up(x)
        return x


def conv3x3(in_planes, out_planes, stride=1):
    # 3x3 convolution with padding
    return nn.Conv2d(in_planes, out_planes, kernel_size=3, stride=stride, padding=1, bias=False)


class AttnIF(nn.Module):
    def __init__(self, in_channels, mid_channels, out_channels):
        super().__init__()
        self.conv1 = conv3x3(in_channels, mid_channels)
        self.bn1 = nn.BatchNorm2d(mid_channels)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = conv3x3(mid_channels, out_channels)
        self.bn2 = nn.BatchNorm2d(out_channels)
        self.ca = ChannelAttention(out_channels)
        self.sa = SpatialAttention()

    def forward(self, x):
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu(out)

        out = self.ca(out) * out
        out = self.sa(out) * out

        return out


class swinv2_unet_plus2_concat(nn.Module):
    def __init__(self, FCCDN=FCCDN()):
    # def __init__(self, vgg16=vgg16_base()):

        super().__init__()
        self.base = FCCDN
        weights_dict = torch.load("/data/dalongzheng/swin_v2/three/networks/FCCDN_best.pth", map_location='cpu')
        msg_FCCDN = self.base.load_state_dict(weights_dict, strict=False)
        print(msg_FCCDN)

        nb_filter = [32, 128, 256, 512, 1024]
        # fe_filter = [128, 256, 512]
        # nb_filter = [32, 64, 128, 256, 512]   # 原网络尺寸
        fe_filter = [64, 128, 256, 512]   # 原网络尺寸的通道数   # 原网络尺寸的分辨率：[256, 128, 64, 32]   # 后来再加16分辨率，但此处未改
        # self.pool = nn.MaxPool2d(2, 2)

        self.up1_0 = up_1(nb_filter[2])
        self.up2_0 = up(nb_filter[2])
        self.up1_1 = up_1(nb_filter[1])
        self.up3_0 = up(nb_filter[3])
        self.up2_1 = up(nb_filter[2])
        self.up1_2 = up_1(nb_filter[1])
        self.up4_0 = up(nb_filter[4])
        self.up3_1 = up(nb_filter[3])
        self.up2_2 = up(nb_filter[2])
        self.up1_3 = up_1(nb_filter[1])

        self.conv0_0 = VggBlock(6, nb_filter[0], nb_filter[0])   # 6, 32, 32

        self.conv0_1 = VggBlock(nb_filter[0] + nb_filter[2], nb_filter[0], nb_filter[0])
        self.conv1_1 = VggBlock(nb_filter[1] + nb_filter[2], nb_filter[1], nb_filter[1])
        self.conv2_1 = VggBlock(nb_filter[2] + nb_filter[3], nb_filter[2], nb_filter[2])

        self.conv0_2 = VggBlock(nb_filter[0] * 2 + nb_filter[1], nb_filter[0], nb_filter[0])
        self.conv1_2 = VggBlock(nb_filter[1] * 2 + nb_filter[2], nb_filter[1], nb_filter[1])

        self.conv0_3 = VggBlock(nb_filter[0] * 3 + nb_filter[1], nb_filter[0], nb_filter[0])

        self.conv0_4 = VggBlock(nb_filter[0] * 4 + nb_filter[1], nb_filter[0], nb_filter[0])

        self.IF1_0 = AttnIF(in_channels=nb_filter[2], mid_channels=nb_filter[2], out_channels=nb_filter[2])
        # self.IF1_0 = AttnIF(in_channels=nb_filter[2] + fe_filter[0] * 2, mid_channels=nb_filter[2] + fe_filter[0], out_channels=nb_filter[2])

        self.IF1_1 = AttnIF(in_channels=384 + 64 * 2, mid_channels=384 + 64, out_channels=384)
        self.IF0_2 = AttnIF(in_channels=nb_filter[1], mid_channels=nb_filter[1], out_channels=nb_filter[1])

        self.IF2_1 = AttnIF(in_channels=384 + 128 * 2, mid_channels=384 + 128, out_channels=384)
        self.IF1_2 = AttnIF(in_channels=512 + 64 * 2, mid_channels=512 + 64, out_channels=512)
        self.IF0_3 = AttnIF(in_channels=nb_filter[1], mid_channels=nb_filter[1], out_channels=nb_filter[1])

        self.IF2_2 = AttnIF(in_channels=768 + 256 * 2, mid_channels=768 + 256, out_channels=768)
        self.IF1_3 = AttnIF(in_channels=768 + 128 * 2, mid_channels=768 + 128, out_channels=768)
        self.IF0_4 = AttnIF(in_channels=640 + 64 * 2, mid_channels=640 + 64, out_channels=640)
        self.IF0_6 = AttnIF(in_channels=128, mid_channels=128, out_channels=128)

        self.final1 = nn.Conv2d(nb_filter[0], 1, 1)
        self.final2 = nn.Conv2d(nb_filter[0], 1, 1)
        self.final3 = nn.Conv2d(nb_filter[0], 1, 1)
        self.final4 = nn.Conv2d(nb_filter[0], 1, 1)

        self.ca = ChannelAttention(nb_filter[0] * 4, ratio=16)
        self.sa = SpatialAttention()
        self.conv_1x1 = nn.Conv2d(nb_filter[0] * 4, 1, 1)
        self.sigmoid = nn.Sigmoid()

        # U型块
        self.SwinTransformerSys = SwinTransformerSys()
        # dict_1 = self.SwinTransformerSys.state_dict()
        # print("model_dict_1['layers.0.blocks.0.norm1.weight']: ", dict_1['layers.0.blocks.0.norm1.weight'])
        load_from(model1=self.SwinTransformerSys, path="/data/ym/weights/swinv2_base_patch4_window16_256.pth")
        # dict_2 = self.SwinTransformerSys.state_dict()
        # print("model_dict_2['layers.0.blocks.0.norm1.weight']: ", dict_2['layers.0.blocks.0.norm1.weight'])

        self.layers_up_0 = self.SwinTransformerSys.layers_up[0]
        self.layers_up_1 = self.SwinTransformerSys.layers_up[1]
        self.layers_up_2 = self.SwinTransformerSys.layers_up[2]
        self.layers_up_3 = self.SwinTransformerSys.layers_up[3]
        self.concat_back_dim_0 = self.SwinTransformerSys.concat_back_dim[0]
        self.concat_back_dim_1 = nn.Linear(768, 512)
        self.concat_back_dim_2 = nn.Linear(768, 256)
        self.concat_back_dim_3 = nn.Linear(640, 128)
        self.norm_up = self.SwinTransformerSys.norm_up

        # 中间三块
        self.upsample_11 = PatchExpand((32, 32), dim=256, dim_scale=2, norm_layer=nn.LayerNorm)
        self.concat_back_dim_11 = nn.Linear(384, 128)
        self.blocks_11 = nn.ModuleList([
            SwinTransformerBlock(dim=128, input_resolution=(64, 64),
                                 num_heads=4, window_size=16,
                                 shift_size=0 if (i % 2 == 0) else 16 // 2,
                                 mlp_ratio=4.,
                                 qkv_bias=True,
                                 drop=0., attn_drop=0.,
                                 drop_path=0.,
                                 norm_layer=nn.LayerNorm,
                                 pretrained_window_size=0)
            for i in range(2)])

        self.upsample_21 = PatchExpand((16, 16), dim=256, dim_scale=2, norm_layer=nn.LayerNorm)
        self.concat_back_dim_21 = nn.Linear(384, 256)
        self.blocks_21 = nn.ModuleList([
            SwinTransformerBlock(dim=256, input_resolution=(32, 32),
                                 num_heads=8, window_size=16,
                                 shift_size=0 if (i % 2 == 0) else 16 // 2,
                                 mlp_ratio=4.,
                                 qkv_bias=True,
                                 drop=0., attn_drop=0.,
                                 drop_path=0.,
                                 norm_layer=nn.LayerNorm,
                                 pretrained_window_size=0)
            for i in range(2)])

        self.upsample_12 = PatchExpand((32, 32), dim=256, dim_scale=2, norm_layer=nn.LayerNorm)
        self.concat_back_dim_12 = nn.Linear(512, 128)
        self.blocks_12 = nn.ModuleList([
            SwinTransformerBlock(dim=128, input_resolution=(64, 64),
                                 num_heads=4, window_size=16,
                                 shift_size=0 if (i % 2 == 0) else 16 // 2,
                                 mlp_ratio=4.,
                                 qkv_bias=True,
                                 drop=0., attn_drop=0.,
                                 drop_path=0.,
                                 norm_layer=nn.LayerNorm,
                                 pretrained_window_size=0)
            for i in range(2)])
        self.fpt = FPT(feature_dim=256)

    def forward(self, t1_input, t2_input):
        t1_list, t2_list = self.base((t1_input, t2_input))

        t1_f_l22, t1_f_l15, t1_f_l8 = t1_list[0], t1_list[1], t1_list[2]
        t2_f_l22, t2_f_l15, t2_f_l8 = t2_list[0], t2_list[1], t2_list[2]

        x0_0 = self.conv0_0(torch.cat((t1_input, t2_input), dim=1))   # (6, 256, 256) -> (32, 256, 256)
        swin0_0 = torch.cat((t1_input, t2_input), dim=1)
        swin4_0, x_downsample = self.SwinTransformerSys.forward_features(swin0_0)
        swin1_0, swin2_0, swin3_0 = x_downsample[0], x_downsample[1], x_downsample[2]
        swin1_0 = swin1_0.transpose(1, 2).view(-1, 128, 64, 64)
        swin2_0 = swin2_0.transpose(1, 2).view(-1, 256, 32, 32)
        swin3_0 = swin3_0.transpose(1, 2).view(-1, 512, 16, 16)
        fpt1_0, fpt2_0, fpt3_0 = self.fpt(swin1_0, swin2_0, swin3_0)
        swin1_0_1 = fpt1_0.view(-1, 256, 4096).transpose(1, 2)
        swin2_0_1 = fpt2_0.view(-1, 256, 1024).transpose(1, 2)
        swin3_0_1 = fpt3_0.view(-1, 256, 256).transpose(1, 2)

        IF1_0 = self.up1_0(fpt1_0)
        IF1_0 = self.IF1_0(IF1_0)   # (256, 256, 256) -> (128, 256, 256)
        # IF1_0 = self.IF1_0(torch.cat((IF1_0, t1_f_l3, t2_f_l3), dim=1))   # (256, 256, 256) -> (128, 256, 256)
        x0_1 = self.conv0_1(torch.cat([IF1_0, x0_0], 1))

        IF1_1 = self.upsample_11(swin2_0_1)
        IF1_1 = torch.cat([IF1_1, swin1_0_1], dim=-1)   # 括号是[]还是()？
        IF1_1 = IF1_1.transpose(1, 2).view(-1, 384, 64, 64)
        IF1_1 = self.IF1_1(torch.cat((IF1_1, t1_f_l8, t2_f_l8), dim=1))
        IF1_1 = IF1_1.view(-1, 384, 4096).transpose(1, 2)
        IF1_1 = self.concat_back_dim_11(IF1_1)
        for blk in self.blocks_11:
                IF1_1 = blk(IF1_1)
        swin1_1_1 = IF1_1
        swin1_1 = swin1_1_1.transpose(1, 2).view(-1, 128, 64, 64)

        IF0_2 = self.up1_1(swin1_1)
        IF0_2 = self.IF0_2(IF0_2)
        x0_2 = self.conv0_2(torch.cat([IF0_2, x0_1, x0_0], 1))

        IF2_1 = self.upsample_21(swin3_0_1)
        IF2_1 = torch.cat([IF2_1, swin2_0_1], dim=-1)   # 括号是[]还是()？
        IF2_1 = IF2_1.transpose(1, 2).view(-1, 384, 32, 32)
        IF2_1 = self.IF2_1(torch.cat((IF2_1, t1_f_l15, t2_f_l15), dim=1))
        IF2_1 = IF2_1.view(-1, 384, 1024).transpose(1, 2)
        IF2_1 = self.concat_back_dim_21(IF2_1)
        for blk in self.blocks_21:
                IF2_1 = blk(IF2_1)
        swin2_1_1 = IF2_1

        IF1_2 = self.upsample_12(swin2_1_1)
        IF1_2 = torch.cat([IF1_2, swin1_1_1, swin1_0_1], dim=-1)   # 括号是[]还是()？
        IF1_2 = IF1_2.transpose(1, 2).view(-1, 512, 64, 64)
        IF1_2 = self.IF1_2(torch.cat((IF1_2, t1_f_l8, t2_f_l8), dim=1))
        IF1_2 = IF1_2.view(-1, 512, 4096).transpose(1, 2)
        IF1_2 = self.concat_back_dim_12(IF1_2)
        for blk in self.blocks_12:
                IF1_2 = blk(IF1_2)
        swin1_2_1 = IF1_2
        swin1_2 = swin1_2_1.transpose(1, 2).view(-1, 128, 64, 64)

        IF0_3 = self.up1_2(swin1_2)
        IF0_3 = self.IF0_3(IF0_3)
        x0_3 = self.conv0_3(torch.cat([IF0_3, x0_2, x0_1, x0_0], 1))

        swin3_1 = self.layers_up_0(swin4_0)

        swin2_2 = torch.cat([swin3_1, swin3_0_1], dim=-1)   # 括号是[]还是()？
        swin2_2 = swin2_2.transpose(1, 2).view(-1, 768, 16, 16)
        swin2_2 = self.IF2_2(torch.cat((swin2_2, t1_f_l22, t2_f_l22), dim=1))
        swin2_2 = swin2_2.view(-1, 768, 256).transpose(1, 2)
        swin2_2 = self.concat_back_dim_1(swin2_2)
        swin2_2 = self.layers_up_1(swin2_2)

        swin1_3 = torch.cat([swin2_2, swin2_1_1, swin2_0_1], dim=-1)
        swin1_3 = swin1_3.transpose(1, 2).view(-1, 768, 32, 32)
        swin1_3 = self.IF1_3(torch.cat((swin1_3, t1_f_l15, t2_f_l15), dim=1))
        swin1_3 = swin1_3.view(-1, 768, 1024).transpose(1, 2)
        swin1_3 = self.concat_back_dim_2(swin1_3)
        swin1_3 = self.layers_up_2(swin1_3)

        swin0_4 = torch.cat([swin1_3, swin1_2_1, swin1_1_1, swin1_0_1], dim=-1)
        swin0_4 = swin0_4.transpose(1, 2).view(-1, 640, 64, 64)
        swin0_4 = self.IF0_4(torch.cat((swin0_4, t1_f_l8, t2_f_l8), dim=1))
        swin0_4 = swin0_4.view(-1, 640, 4096).transpose(1, 2)
        swin0_4 = self.concat_back_dim_3(swin0_4)
        swin0_4 = self.layers_up_3(swin0_4)
        swin0_4 = self.norm_up(swin0_4)
        swin0_4 = swin0_4.transpose(1, 2).view(-1, 128, 64, 64)

        swin0_4 = self.up1_3(swin0_4)
        swin0_4 = self.IF0_6(swin0_4)
        x0_4 = self.conv0_4(torch.cat([swin0_4, x0_3, x0_2, x0_1, x0_0], 1))

        # 四个中间输出做深监督
        output1 = self.sigmoid(self.final1(x0_1))
        output2 = self.sigmoid(self.final2(x0_2))
        output3 = self.sigmoid(self.final3(x0_3))
        output4 = self.sigmoid(self.final4(x0_4))

        out = torch.cat([x0_4, x0_3, x0_2, x0_1], 1)
        out = self.ca(out)*out
        out = self.sa(out)*out
        out = self.sigmoid(self.conv_1x1(out))

        return [output1, output2, output3, output4, out]



if __name__ == '__main__':
    img1 = torch.rand((2, 3, 256, 256)).cuda(2)
    img2 = torch.rand((2, 3, 256, 256)).cuda(2)
    model = swinv2_unet_plus2_concat()
    model = model.cuda(2)
    output = model(img1, img2)
    print(output[-1].shape)
